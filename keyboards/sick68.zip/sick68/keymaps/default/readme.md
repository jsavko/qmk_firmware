# The default keymap for sick68
